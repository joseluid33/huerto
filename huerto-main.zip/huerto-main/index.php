<?php

/*
 * Redirige la raíz del proyecto a la carpeta pública de CodeIgniter 4.
 * Así http://localhost/huerto-main/ funciona sin tener que escribir /public/.
 */
header('Location: public/', true, 302);
exit;
