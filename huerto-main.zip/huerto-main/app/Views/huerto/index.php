<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>

<div class="container mt-4 mb-5">

    <div class="d-flex flex-wrap justify-content-between align-items-center mb-4">
        <div>
            <h1 class="titulo-panel">🌱 Mi Huerto</h1>
            <p class="subtitulo-panel mb-0">Estado general de tus cultivos de hoy</p>
        </div>
        <a href="<?= base_url('huerto/nuevo') ?>" class="btn btn-success">
            + Nuevo cultivo
        </a>
    </div>

    <!-- Tarjetas de resumen -->
    <div class="row g-3 mb-4">

        <div class="col-6 col-lg-3">
            <div class="card card-resumen">
                <div class="card-body">
                    <div class="resumen-icono icono-total">🌿</div>
                    <div>
                        <div class="resumen-numero"><?= $totalCultivos ?></div>
                        <div class="resumen-etiqueta">Cultivos</div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-6 col-lg-3">
            <div class="card card-resumen">
                <div class="card-body">
                    <div class="resumen-icono icono-riego">💧</div>
                    <div>
                        <div class="resumen-numero"><?= $requierenRiego ?></div>
                        <div class="resumen-etiqueta">Riego hoy</div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-6 col-lg-3">
            <div class="card card-resumen">
                <div class="card-body">
                    <div class="resumen-icono icono-cosecha">🥬</div>
                    <div>
                        <div class="resumen-numero"><?= $listosCosecha ?></div>
                        <div class="resumen-etiqueta">Cosechar</div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-6 col-lg-3">
            <div class="card card-resumen">
                <div class="card-body">
                    <div class="resumen-icono icono-termi">🧺</div>
                    <div>
                        <div class="resumen-numero"><?= $cosechados ?></div>
                        <div class="resumen-etiqueta">Cosechados</div>
                    </div>
                </div>
            </div>
        </div>

    </div>

    <!-- Listado de cultivos (tabla) -->
    <div class="panel-tabla">

        <?php if (empty($cultivos)): ?>

            <div class="estado-vacio">
                <div class="icono">🪴</div>
                <h5 class="mt-2 fw-semibold">Todavía no tenés cultivos</h5>
                <p class="mb-3">Cargá tu primer cultivo y empezá a llevar la bitácora.</p>
                <a href="<?= base_url('huerto/nuevo') ?>" class="btn btn-success">+ Nuevo cultivo</a>
            </div>

        <?php else: ?>

            <div class="table-responsive">
                <table class="table table-huerto align-middle">

                    <thead>
                        <tr>
                            <th>Cultivo</th>
                            <th>Siembra</th>
                            <th>Próximo riego</th>
                            <th>Cosecha estimada</th>
                            <th>Estado</th>
                            <th>Alertas</th>
                            <th class="text-end">Acciones</th>
                        </tr>
                    </thead>

                    <tbody>

                        <?php foreach ($cultivos as $cultivo): ?>

                            <?php
                                $filaAlerta = $cultivo['requiere_riego'] ? 'fila-riego' : ($cultivo['listo_cosechar'] ? 'fila-cosecha' : '');
                                $proximoRiego = $cultivo['proximo_riego']
                                    ? date('d/m/Y', strtotime($cultivo['proximo_riego']))
                                    : '—';
                                $fechaCosecha = $cultivo['fecha_cosecha_estimada']
                                    ? date('d/m/Y', strtotime($cultivo['fecha_cosecha_estimada']))
                                    : '—';
                            ?>

                            <tr class="<?= $filaAlerta ?>">

                                <td>
                                    <div class="nombre-planta"><?= esc($cultivo['nombre_planta']) ?></div>
                                    <?php if (! empty($cultivo['variedad'])): ?>
                                        <span class="variedad-planta"><?= esc($cultivo['variedad']) ?></span>
                                    <?php endif; ?>
                                </td>

                                <td class="fecha-cell">
                                    <?= date('d/m/Y', strtotime($cultivo['fecha_siembra'])) ?>
                                </td>

                                <td class="fecha-cell">
                                    <span class="<?= $cultivo['requiere_riego'] ? 'fecha-proxima text-warning fw-bold' : '' ?>">
                                        <?= $proximoRiego ?>
                                    </span>
                                </td>

                                <td class="fecha-cell">
                                    <?= $fechaCosecha ?>
                                </td>

                                <td>
                                    <?php if ($cultivo['estado'] === 'Listo para Cosechar'): ?>
                                        <span class="badge badge-estado badge-listo">Listo para Cosechar</span>
                                    <?php elseif ($cultivo['estado'] === 'Cosechado'): ?>
                                        <span class="badge badge-estado badge-cosechado">Cosechado</span>
                                    <?php else: ?>
                                        <span class="badge badge-estado badge-crecimiento">En Crecimiento</span>
                                    <?php endif; ?>
                                </td>

                                <td>
                                    <div class="d-flex flex-column gap-1">

                                        <?php if ($cultivo['requiere_riego']): ?>
                                            <span class="badge-alerta badge-alerta-riego">💧 Requiere riego hoy</span>
                                        <?php endif; ?>

                                        <?php if ($cultivo['listo_cosechar']): ?>
                                            <span class="badge-alerta badge-alerta-cosecha">🌿 Listo para cosechar</span>
                                        <?php endif; ?>

                                    </div>
                                </td>

                                <td class="text-end">
                                    <div class="d-flex flex-column flex-lg-row gap-1 justify-content-lg-end">

                                        <form action="<?= base_url('huerto/registrarRiego/' . $cultivo['id']) ?>" method="post">
                                            <button type="submit" class="btn btn-accion btn-mini-riego w-100">💧 Riego</button>
                                        </form>

                                        <form
                                            action="<?= base_url('huerto/cambiarEstado/' . $cultivo['id']) ?>"
                                            method="post"
                                            class="form-estado d-flex flex-column flex-lg-row gap-1"
                                            data-nombre="<?= esc($cultivo['nombre_planta'], 'attr') ?>"
                                            data-estado-actual="<?= esc($cultivo['estado'], 'attr') ?>"
                                        >
                                            <select name="estado" class="form-select select-estado">
                                                <option value="En Crecimiento" <?= $cultivo['estado'] === 'En Crecimiento' ? 'selected' : '' ?>>En Crecimiento</option>
                                                <option value="Listo para Cosechar" <?= $cultivo['estado'] === 'Listo para Cosechar' ? 'selected' : '' ?>>Listo para Cosechar</option>
                                                <option value="Cosechado" <?= $cultivo['estado'] === 'Cosechado' ? 'selected' : '' ?>>Cosechado</option>
                                            </select>
                                            <button type="submit" class="btn btn-accion btn-mini-estado">Estado</button>
                                        </form>

                                        <button
                                            type="button"
                                            class="btn btn-accion btn-mini-eliminar"
                                            data-bs-toggle="modal"
                                            data-bs-target="#modalEliminar"
                                            data-url="<?= base_url('huerto/eliminar/' . $cultivo['id']) ?>"
                                            data-nombre="<?= esc($cultivo['nombre_planta'], 'attr') ?>"
                                        >🗑️ Eliminar</button>

                                    </div>
                                </td>

                            </tr>

                        <?php endforeach; ?>

                    </tbody>

                </table>
            </div>

        <?php endif; ?>

    </div>

</div>

<!-- Modal de advertencia: eliminar cultivo -->
<div class="modal fade modal-huerto modal-eliminar" id="modalEliminar" tabindex="-1" aria-labelledby="modalEliminarTitulo" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-cuerpo">

                <div class="modal-icono modal-icono-eliminar">🗑️</div>

                <h5 class="modal-titulo" id="modalEliminarTitulo">¿Quitar este cultivo?</h5>
                <p class="modal-texto">
                    Vas a eliminar <strong id="eliminarNombre"></strong> de tu huerto.<br>
                    Esta acción no se puede deshacer.
                </p>

                <div class="modal-acciones">
                    <button type="button" class="btn btn-cancelar-modal" data-bs-dismiss="modal">Cancelar</button>
                    <a href="#" id="btnEliminarConfirmar" class="btn btn-peligro-modal">Sí, quitar</a>
                </div>

            </div>
        </div>
    </div>
</div>

<!-- Modal de advertencia: cambiar estado -->
<div class="modal fade modal-huerto modal-aviso" id="modalEstado" tabindex="-1" aria-labelledby="modalEstadoTitulo" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-cuerpo">

                <div class="modal-icono modal-icono-aviso">🔄</div>

                <h5 class="modal-titulo" id="modalEstadoTitulo">¿Cambiar el estado?</h5>
                <p class="modal-texto" id="estadoTexto"></p>

                <div class="modal-acciones">
                    <button type="button" class="btn btn-cancelar-modal" data-bs-dismiss="modal">Cancelar</button>
                    <button type="button" class="btn btn-confirmar-modal" id="btnEstadoConfirmar">Sí, cambiar</button>
                </div>

            </div>
        </div>
    </div>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function () {
        // ---- Eliminar cultivo ----
        const modalEliminar = document.getElementById('modalEliminar');
        const nombreEliminar = document.getElementById('eliminarNombre');
        const btnEliminar = document.getElementById('btnEliminarConfirmar');

        modalEliminar.addEventListener('show.bs.modal', function (event) {
            const boton = event.relatedTarget;
            nombreEliminar.textContent = boton.dataset.nombre;
            btnEliminar.href = boton.dataset.url;
        });

        // ---- Cambiar estado ----
        const modalEstadoEl = document.getElementById('modalEstado');
        const modalEstado = new bootstrap.Modal(modalEstadoEl);
        const estadoTexto = document.getElementById('estadoTexto');
        const btnEstado = document.getElementById('btnEstadoConfirmar');
        let formPendiente = null;

        document.querySelectorAll('.form-estado').forEach(function (form) {
            form.addEventListener('submit', function (event) {
                const nuevoEstado = form.querySelector('select[name="estado"]').value;
                const estadoActual = form.dataset.estadoActual;

                // Si no cambió el estado, se envía sin advertencia.
                if (nuevoEstado === estadoActual) {
                    return;
                }

                event.preventDefault();
                formPendiente = form;

                estadoTexto.innerHTML = 'Vas a cambiar <strong></strong> de <span class="estado-actual"></span> a <span class="estado-nuevo"></span>.';
                estadoTexto.querySelector('strong').textContent = form.dataset.nombre;
                estadoTexto.querySelector('.estado-actual').textContent = estadoActual;
                estadoTexto.querySelector('.estado-nuevo').textContent = nuevoEstado;

                modalEstado.show();
            });
        });

        btnEstado.addEventListener('click', function () {
            if (formPendiente) {
                formPendiente.submit();
            }
        });
    });
</script>

<?= $this->endSection() ?>